<?php

//create a script to consruct the following pattern, using a nested for loop.


for($i=0;$i<=5;$i++)
{
for($j=5-$i;$j>=1;$j--)
{
echo "* ";
}
echo "<br>";
}
?>